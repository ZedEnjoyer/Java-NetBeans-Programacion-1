/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.githubzedenjoyer.programacion1;

/**
 *
 * @author salas
 */
public class Docente {
    
    private String nombre;
    private String especialidad;
    private int edad;
    
    public Docente (String nombre, String especialidad,int edad){
        this.nombre = nombre;
        this.edad = edad;
        this.especialidad = especialidad;
    }
    
    public String setEspecialidad(String especialidad){
        if(especialidad == ""){
            return "El estudiante no debe contener mas de 10 caracteres";
        }
        
        this.nombre = nombre;
        return "Nombre actualizado";
    }
    
}
