/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.githubzedenjoyer.programacion1;

/**
 *
 * @author salas
 */
public class Estudiante {
    
    private String nombre;
    int edad;
    
    public Estudiante (String nombre,int edad){
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public String setNombre(String nombre){
        if(nombre.length() > 10){
            return "El estudiante no debe contener mas de 10 caracteres";
        }
        
        this.nombre = nombre;
        return "Nombre actualizado";
    }
    
}
