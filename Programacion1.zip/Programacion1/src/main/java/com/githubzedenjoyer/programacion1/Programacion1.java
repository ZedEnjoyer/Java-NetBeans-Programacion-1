/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.githubzedenjoyer.programacion1;

/**
 *
 * @author salas
 */
public class Programacion1 {

    public static void main(String[] args) {
        
        Estudiante est1 = new Estudiante("Andres",15);
        
        
        est1.edad = 17;
        est1.setNombre ("Nigga");
    }
    
    
}
